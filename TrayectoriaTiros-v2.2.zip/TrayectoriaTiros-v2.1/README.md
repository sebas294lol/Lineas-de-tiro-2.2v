# Trayectoria de Tiros v2.1

Simulador 2D de fútbol independiente. Incluye Normal, Retos, Modo Portero, Tiros Libres y Penales, con potencia, altura, curva, portero, bot tirador, objetivos, récords y controles táctiles.

## GitHub Actions
Este proyecto ya trae `.github/workflows/build.yml`. Sube el contenido del proyecto directamente al repositorio (no un ZIP dentro de otro ZIP) y ejecuta Actions > Build APK > Run workflow.
