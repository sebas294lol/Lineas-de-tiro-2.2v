package com.trayectoriadetiros;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(4,16,9));
        getWindow().setNavigationBarColor(Color.rgb(4,16,9));
        game=new GameView(this); setContentView(game);
    }
    @Override public void onBackPressed(){
        if(game.screen!=0){game.screen=0;game.reset();game.invalidate();} else super.onBackPressed();
    }
}

class GameView extends View {
    final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); final Random rng=new Random();
    final ArrayList<PointF> trail=new ArrayList<>();
    Bitmap playerBmp, keeperBmp, pitchBmp, netBmp;
    int screen=0; // menu, normal, retos, portero, libres, penales
    int difficulty=1;
    float power=70, curve=0, height=55;
    float ballX,ballY,startX,startY,targetX,targetY;
    float keeperX,keeperY,keeperGoalX,keeperGoalY;
    float anim=0, playerAnim=0, keeperAnim=0;
    boolean shooting=false, keeperDiving=false, draggingKeeper=false;
    boolean saved=false, goal=false;
    long last=0, toastUntil=0;
    int attempts=0, goals=0, saves=0, challenge=0, streak=0, record=0;
    int W,H; String toast="";

    GameView(Context c){
        super(c); setFocusable(true); p.setTypeface(Typeface.create("sans",Typeface.BOLD));
        playerBmp=load(c, "player_sprite"); keeperBmp=load(c,"keeper_sprite");
        pitchBmp=load(c,"pitch_texture"); netBmp=load(c,"net_texture"); reset();
    }
    Bitmap load(Context c,String n){int id=c.getResources().getIdentifier(n,"drawable",c.getPackageName());return id==0?null:BitmapFactory.decodeResource(c.getResources(),id);}
    void reset(){
        ballX=ballY=startX=startY=targetX=targetY=keeperX=keeperY=keeperGoalX=keeperGoalY=0;
        anim=playerAnim=keeperAnim=0; shooting=keeperDiving=draggingKeeper=false; saved=goal=false;trail.clear();
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c); W=getWidth(); H=getHeight();
        if(screen==0) drawMenu(c); else {drawPitch(c); if(shooting){if(screen==3) updateKeeperShot(); else updateShot();} drawScene(c); drawControls(c);}
        if(toastUntil>System.currentTimeMillis()){round(c,18,H-68,W-18,H-18,18,0xe9111111);text(c,toast,W/2,H-38,15,Color.WHITE,Paint.Align.CENTER);postInvalidateDelayed(30);}
    }
    void drawMenu(Canvas c){
        c.drawColor(Color.rgb(5,18,10));
        text(c,"⚽ TRAYECTORIA DE TIROS",W/2,70,25,Color.WHITE,Paint.Align.CENTER);
        text(c,"Simulador de fútbol",W/2,99,14,0xffa8d8b4,Paint.Align.CENTER);
        String[] names={"🎯  NORMAL","🏆  RETOS","🧤  MODO PORTERO","⚽  TIROS LIBRES","🥅  PENALES"};
        int[] cols={0xff176b37,0xff145d83,0xff70451b,0xff5a3a77,0xff75402e};
        float top=Math.max(150,H*.22f), gap=Math.min(72,(H-230)/5f);
        for(int i=0;i<5;i++) button(c,names[i],top+i*gap,cols[i]);
        text(c,"v2.2 • récord de racha: "+record,W/2,H-30,12,0xff8aa391,Paint.Align.CENTER);
    }
    void drawPitch(Canvas c){
        p.setStyle(Paint.Style.FILL); p.setColor(0xff176f3b); c.drawRect(0,0,W,H,p);
        if(pitchBmp!=null){p.setAlpha(32);c.drawBitmap(pitchBmp,null,new Rect(0,0,W,H),p);p.setAlpha(255);}
        p.setStyle(Paint.Style.FILL); p.setColor(0x22000000);
        for(int i=0;i<10;i++) if(i%2==0)c.drawRect(i*W/10f,0,(i+1)*W/10f,H,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xffe4f5e6);
        c.drawRect(16,32,W-16,H-16,p);c.drawLine(W/2f,32,W/2f,H-16,p);c.drawCircle(W/2f,H*.54f,54,p);
        float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;
        p.setStrokeWidth(5);c.drawRect(gx,gy,gx+gw,gy+gh,p);p.setStrokeWidth(2);c.drawRect(gx-30,gy+45,gx+gw+30,gy+gh-45,p);
        if(netBmp!=null){p.setAlpha(70);c.drawBitmap(netBmp,null,new RectF(gx,gy,gx+gw,gy+gh),p);p.setAlpha(255);}
    }
    void drawScene(Canvas c){
        String title=modeName(); round(c,10,8,W-10,58,16,0xcc092012);text(c,title,22,40,18,Color.WHITE,Paint.Align.LEFT);
        text(c,"Goles "+goals+"  •  Tiros "+attempts+"  •  Racha "+streak,W-22,39,12,0xffd5ead9,Paint.Align.RIGHT);
        if(!shooting && screen!=3){p.setStyle(Paint.Style.FILL);p.setColor(0x55ffffff);c.drawCircle(targetX,targetY,17,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.WHITE);c.drawCircle(targetX,targetY,17,p);}
        if(trail.size()>1){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(0xffffe66d);Path q=new Path();q.moveTo(trail.get(0).x,trail.get(0).y);for(int i=1;i<trail.size();i++)q.lineTo(trail.get(i).x,trail.get(i).y);c.drawPath(q,p);}
        if(screen!=3 || keeperX>0) drawKeeper(c,keeperX,keeperY,keeperDiving);
        if(startX>0) drawPlayer(c,startX,startY,shooting);
        if(ballX>0){p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(ballX,ballY,10,p);p.setStyle(Paint.Style.STROKE);p.setColor(0xff555555);p.setStrokeWidth(1);c.drawCircle(ballX,ballY,10,p);}
    }
    String modeName(){return screen==1?"🎯 NORMAL":screen==2?"🏆 RETOS":screen==3?"🧤 MODO PORTERO":screen==4?"⚽ TIRO LIBRE":"🥅 PENAL";}
    void drawControls(Canvas c){
        float y=H-218;
        if(screen==3){
            text(c,"👆 Toca el arco para lanzarte • arrastra al portero",W/2,y,13,Color.WHITE,Paint.Align.CENTER);
            buttonSmall(c,"Fácil",W*.20f,y+34,difficulty==0);buttonSmall(c,"Medio",W*.50f,y+34,difficulty==1);buttonSmall(c,"Difícil",W*.80f,y+34,difficulty==2);
            buttonSmall(c,"🔙 Menú",W*.22f,y+84,false);buttonSmall(c,"🤖 NUEVO TIRO",W*.78f,y+84,true);
        }else{
            text(c,"Potencia",W*.17f,y,12,Color.WHITE,Paint.Align.CENTER);text(c,"Curva",W*.50f,y,12,Color.WHITE,Paint.Align.CENTER);text(c,"Altura",W*.83f,y,12,Color.WHITE,Paint.Align.CENTER);
            slider(c,W*.07f,W*.28f,y+25,power,1,100);slider(c,W*.39f,W*.61f,y+25,curve,-40,40);slider(c,W*.71f,W*.93f,y+25,height,10,90);
            buttonSmall(c,"🔙 Menú",W*.19f,y+74,false);buttonSmall(c,screen==2?"🎯 RETO":"⚽ DISPARAR",W*.50f,y+74,true);buttonSmall(c,"🆕",W*.81f,y+74,false);
            if(screen==1||screen==2){text(c,"Dificultad",W/2,y+108,12,Color.WHITE,Paint.Align.CENTER);buttonSmall(c,"Fácil",W*.25f,y+137,difficulty==0);buttonSmall(c,"Medio",W*.50f,y+137,difficulty==1);buttonSmall(c,"Difícil",W*.75f,y+137,difficulty==2);}
        }
    }
    void slider(Canvas c,float l,float r,float y,float val,float min,float max){p.setStrokeWidth(7);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(0x88ffffff);c.drawLine(l,y,r,y,p);float q=(val-min)/(max-min);p.setColor(0xffffe66d);c.drawLine(l,y,l+(r-l)*q,y,p);p.setColor(Color.WHITE);c.drawCircle(l+(r-l)*q,y,10,p);p.setStrokeCap(Paint.Cap.BUTT);}
    void button(Canvas c,String s,float cy,int color){float l=W*.12f,r=W*.88f;round(c,l,cy-25,r,cy+25,16,color);text(c,s,W/2,cy+7,17,Color.WHITE,Paint.Align.CENTER);}
    void buttonSmall(Canvas c,String s,float cx,float cy,boolean on){round(c,cx-62,cy-21,cx+62,cy+21,13,on?0xffa56f14:0x66303030);text(c,s,cx,cy+6,12,Color.WHITE,Paint.Align.CENTER);}
    void drawPlayer(Canvas c,float x,float y,boolean moving){
        float step=moving?(float)Math.sin(playerAnim*13)*7:0;
        if(playerBmp!=null){RectF d=new RectF(x-28+step,y-58,x+28+step,y);c.drawBitmap(playerBmp,null,d,p);return;}
        p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(x,y-38,10,p);c.drawRoundRect(x-10,y-29,x+10,y+5,5,5,p);p.setStrokeWidth(5);c.drawLine(x-5,y+4,x-12+step,y+28,p);c.drawLine(x+5,y+4,x+12-step,y+28,p);
    }
    void drawKeeper(Canvas c,float x,float y,boolean dive){if(x==0)return;float d=dive?Math.min(1,keeperAnim*2.2f):0;float xx=x+(keeperGoalX-x)*d,yy=y+(keeperGoalY-y)*d; if(keeperBmp!=null){c.drawBitmap(keeperBmp,null,new RectF(xx-32,yy-70,xx+32,yy+5),p);return;}p.setStyle(Paint.Style.FILL);p.setColor(0xffffd35a);c.drawCircle(xx,yy-48,10,p);p.setColor(0xff2d65c8);c.drawRoundRect(xx-12,yy-38,xx+12,yy-4,6,6,p);p.setStrokeWidth(5);c.drawLine(xx-8,yy-5,xx-17,yy+22,p);c.drawLine(xx+8,yy-5,xx+17,yy+22,p);}
    void chooseDefault(){float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;targetX=gx+gw*.65f;targetY=gy+gh*.50f;keeperX=gx+gw*.5f;keeperY=gy+gh*.82f;startX=W*.18f;startY=H*.63f;}
    void ensure(){if(targetX==0)chooseDefault();}
    void shoot(){if(shooting)return;ensure();attempts++;if(screen==2)challenge++;if(screen==2){float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;targetX=gx+gw*(.12f+rng.nextFloat()*.76f);targetY=gy+gh*(.10f+rng.nextFloat()*.80f);}startX=W*.18f;startY=H*.63f;beginShot();}
    void beginShot(){shooting=true;anim=0;playerAnim=0;ballX=startX;ballY=startY;trail.clear();saved=goal=false;keeperDiving=false;keeperAnim=0;float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;keeperX=gx+gw*.5f;keeperY=gy+gh*.82f;keeperGoalX=targetX;keeperGoalY=targetY;last=System.currentTimeMillis();}
    void updateShot(){float now=System.currentTimeMillis();float dt=Math.min(.05f,(now-last)/1000f);last=now;anim+=dt;playerAnim+=dt;float duration=.95f-(power/100f)*.42f;float t=Math.min(1,anim/duration);float sx=startX,sy=startY,ex=targetX,ey=targetY;float x=sx+(ex-sx)*t;float lift=(float)Math.sin(Math.PI*t)*(height/100f)*150f;float side=(float)Math.sin(Math.PI*t)*curve*2.15f;ballX=x+side;ballY=sy+(ey-sy)*t-lift;trail.add(new PointF(ballX,ballY));keeperAnim=Math.max(0,t-.45f)*1.7f;if(t>=1){shooting=false;resolveShot();}}
    void resolveShot(){float chance=.18f+difficulty*.10f;if(screen==4)chance=.20f;if(screen==5)chance=.16f;boolean save=rng.nextFloat()<chance && height<82;if(save){saved=true;saves++;streak=0;toast="🧤 ¡ATAJADA!";}else{goal=true;goals++;streak++;record=Math.max(record,streak);toast="⚽ ¡GOL!";}toastUntil=System.currentTimeMillis()+1000;invalidate();}
    void botShotKeeper(){if(shooting)return;attempts++;float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;startX=W*(.16f+rng.nextFloat()*.25f);startY=H*(.47f+rng.nextFloat()*.18f);targetX=gx+gw*(.08f+rng.nextFloat()*.84f);targetY=gy+gh*(.08f+rng.nextFloat()*.84f);if(difficulty==0){curve=0;height=40;power=50;}else if(difficulty==1){curve=-18+rng.nextFloat()*36;height=35+rng.nextFloat()*35;power=65+rng.nextFloat()*20;}else{curve=-40+rng.nextFloat()*80;height=20+rng.nextFloat()*65;power=80+rng.nextFloat()*20;}ballX=startX;ballY=startY;trail.clear();anim=0;playerAnim=0;keeperDiving=false;keeperAnim=0;last=System.currentTimeMillis();shooting=true;invalidate();}
    void updateKeeperShot(){float now=System.currentTimeMillis();float dt=Math.min(.05f,(now-last)/1000f);last=now;anim+=dt;float duration=.92f-power*.0038f;float t=Math.min(1,anim/duration);float x=startX+(targetX-startX)*t;float lift=(float)Math.sin(Math.PI*t)*(height/100f)*145f;float side=(float)Math.sin(Math.PI*t)*curve*2.2f;ballX=x+side;ballY=startY+(targetY-startY)*t-lift;trail.add(new PointF(ballX,ballY));if(keeperDiving){keeperAnim=Math.min(1,anim/.42f);}if(t>=1){shooting=false;resolveKeeper();}}
    void resolveKeeper(){float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;float px=keeperX+(keeperGoalX-keeperX)*Math.min(1,keeperAnim*2.2f),py=keeperY+(keeperGoalY-keeperY)*Math.min(1,keeperAnim*2.2f);float dist=(float)Math.hypot(targetX-px,targetY-py);boolean caught=dist<48+(difficulty==0?10:0);if(caught){saves++;streak++;record=Math.max(record,streak);toast="🧤 ¡ATAJADA!";}else{goals++;streak=0;toast="⚽ ¡GOL!";}toastUntil=System.currentTimeMillis()+1000;invalidate();}
    void setKeeperTarget(float x,float y){keeperGoalX=x;keeperGoalY=y;keeperDiving=true;keeperAnim=0;}
    @Override public boolean onTouchEvent(MotionEvent e){
        float x=e.getX(),y=e.getY();
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            if(screen==0){float top=Math.max(150,H*.22f),gap=Math.min(72,(H-230)/5f);for(int i=0;i<5;i++)if(y>top+i*gap-30&&y<top+i*gap+30){screen=i+1;reset();invalidate();return true;}return true;}
            if(screen==3){float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;if(Math.hypot(x-keeperX,y-keeperY)<65&&!shooting){draggingKeeper=true;return true;}if(x>gx-35&&x<gx+gw+35&&y>gy-25&&y<gy+gh+25&&!shooting){setKeeperTarget(x,y);botShotKeeper();return true;}}
        }
        if(screen==3&&e.getAction()==MotionEvent.ACTION_MOVE&&draggingKeeper&&!shooting){float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;keeperX=Math.max(gx,Math.min(gx+gw,x));keeperY=Math.max(gy+gh*.48f,Math.min(gy+gh,y));invalidate();return true;}
        if(screen==3&&e.getAction()==MotionEvent.ACTION_UP){draggingKeeper=false;float y0=H-218;if(y>y0+45){if(x<W*.38f){screen=0;reset();invalidate();return true;}if(x>W*.62f){botShotKeeper();return true;} }return true;}
        if(e.getAction()==MotionEvent.ACTION_UP&&screen!=0){float y0=H-218;
            if(y>y0+45&&y<y0+105){if(x<W*.34f){screen=0;reset();invalidate();return true;}if(x>W*.34f&&x<W*.66f){if(screen==1||screen==2||screen==4||screen==5)shoot();return true;}reset();invalidate();return true;}
            if((screen==1||screen==2)&&y>y0+105){difficulty=x<W*.38f?0:(x<W*.62f?1:2);invalidate();return true;}
            if(y>y0-5&&y<y0+48){float l=W*.07f,r=W*.28f;if(x>=l&&x<=r)power=clamp((x-l)/(r-l)*99+1,1,100);l=W*.39f;r=W*.61f;if(x>=l&&x<=r)curve=clamp((x-l)/(r-l)*80-40,-40,40);l=W*.71f;r=W*.93f;if(x>=l&&x<=r)height=clamp((x-l)/(r-l)*80+10,10,90);invalidate();return true;}
            float gx=W*.74f,gy=H*.20f,gw=W*.23f,gh=H*.56f;if(x>gx&&x<gx+gw&&y>gy&&y<gy+gh&&!shooting){targetX=x;targetY=y;invalidate();return true;}
        }
        return true;
    }
    float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
    void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){p.setTextSize(size);p.setColor(color);p.setTextAlign(align);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
    void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);}
}
